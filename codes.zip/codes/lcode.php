<?php 
session_start();
$uid=$_POST["uid"];
$passwd=$_POST["passwd"];
$cmd="select userid,passwd from login where userid='$uid' and passwd='$passwd'";
$conn=mysqli_connect("localhost","root","","yatidb");
if($conn==true)
{
$x=mysqli_query($conn,$cmd);
if(mysqli_num_rows($x))
{
$row=mysqli_fetch_assoc($x);
$email=$row["userid"];
$p=$row["passwd"];
if($email==$uid && $p==$passwd)
{
//set value into session 
$_SESSION["aid"]=$email;
echo "<script>alert('Welcome to AdminZone');window.location.href='../Admin/dashboard.php'</script>";
}
else
{
echo "<script>alert('Invalid UserId or Password');window.location.href='../login.php'</script>";
}
}
else
{
echo "<script>alert('Invalid UserId or Password');window.location.href='../login.php'</script>";
}
}
?>